@extends('layouts.admin-master')
@section('content')

Hello
@endsection