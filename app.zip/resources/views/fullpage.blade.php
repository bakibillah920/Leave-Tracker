@extends('layouts.admin-master')
@section('content')
    {!! $viewpage !!}
@endsection
