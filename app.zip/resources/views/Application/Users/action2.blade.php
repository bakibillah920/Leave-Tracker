<a href="javascript:void(0)" data-id="{{ $id }}" data-toggle="tooltip" data-original-title="Edit" class="btn btn-default btn-circle icon">
   <i class="fas fa-pen-nib"></i>
</a>