<?php

return [

    "edit" => "Edit",
    "branch" => "Branch",
    "name" => "Name",
    "gender" => "Gender",
    "leave" => "Leave List",
    "leave_add" => "Leave Add",
    "sl" => "SL",
    "applicant" => "Applicant",
    "leave_category" => "Leave Category",
    "date_of_start" => "Date Of Start",
    "date_of_end" => "Date Of End",
    "days" => "Days",
    "reason" => "Reason",
    "leave_date" => "Leave Date",
    "apply_date" => "Apply Date",
    "status" => "Status",
    'action' => 'Action',
    "role" => "Role",
    "select_ground" => "Select Ground",
    'filter' => 'Filter',
    'comment' => 'comment',
    "created_at" => "Created At",
    "updated_at" => "Updated At",
];
