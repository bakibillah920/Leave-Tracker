<?php

return [
    "role" => "Role",
    "list" => "List",
    "sl" => "SL",
    "name" => "Name",
    "system_role" => "System Role",
    "action" => "Action",
    "permission" => "Permission",
    "yes" => "Yes",
    "create" => "Create",
    "update" => "Update",
    "delete" => "Delete",
    "edit" => "Edit",
    "save" => "Save",
    "role_permission_for" => "Role Permission For",
    "feature" => "Feature",
    "view" => "View",
    "add" => "Add",
];