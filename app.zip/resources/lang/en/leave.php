<?php 

return [
    'leave_type'                       => 'Leave Type',
    'attachment'                       => 'Attachment',
    'date'                             => 'Date',
    'reason'                           => 'Reasons',
    'action'                           => 'Action',
    'edit_leave_request'              => 'Edit Leave Request',
    'update'                           => 'Update',
    'cancel'                           =>'Cancel',
    'applicant'                        =>'Applicant',
    'leave_category'                   =>'Leave Category',
    'date_of_start'                     =>'Date Of Start',
    'date_of_end'                       =>'Date Of End',
    'days'                             =>'Days',
    'apply_date'                        =>'Apply Date',
    'status'                            =>'Status',
    'action'                           =>'Action',
    'leave_list'                        =>'Leave List',
    'leave_request'                     =>'Leave Request',
    'user'                     =>'User'
];


?>