<?php 

return [
    'leave_category_name'        => 'Leave Category Name',
    'role'                       => 'Role',
    'day'                         => 'Days',
    'leave_category_list'         => 'Leave Category List',
    'name'                        => 'Name',
    'action'                       => 'Action',
    'edit_leave_category'         => 'Edit Leave Category',
    'update'                      => 'Update',
    'cancel'                     =>'Cancel',
];


?>